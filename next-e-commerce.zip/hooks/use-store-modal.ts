import { create } from "zustand";

interface useStoreModalInterface {

}