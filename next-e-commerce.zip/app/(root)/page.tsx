"use client";

import { Button } from "@/components/ui/button";
import { Modal } from "@/components/ui/modal";
import { SignedIn, UserButton } from "@clerk/nextjs";

const SetupPage = () => {
  return (
    <div>
      <SignedIn>
        <UserButton />
      </SignedIn>
      <Modal
        title="test"
        description="test desc"
        isOpen
        onClose={() => {}}
      ></Modal>
    </div>
  );
};

export default SetupPage;
